function saveFile(){
    const username = document.getElementById('username');
    const password = document.getElementById('password');
    
    let data = 
    '\r username:' + username.value + '\r\n'+
    'password:' +password.value+'\r\n';
    
    const textToBLOB = new Blob([data],{type:'type/plain'});
    const sFileName = 'formatData.txt';
    
    let newLink = document.createElement("a");
    newLink.download = sFileName;
    
    if(window.webkitURL != null){
        newLink.href = window.webkitURL.createObjectURL(textToBLOB);
    }else{
        newLink.href = window.URL.createObjectURL(textToBLOB);
        newLink.style.display = "none";
        document.body.appendChild(newLink);
    }
    
    newLink.click();
    
}
