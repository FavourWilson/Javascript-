let Names = ["Alice","Bob","jeremy","Sam","Henry","sarah","Ashley"]
function displayAlice(){
    alert("Hello my name is" + Names[0] + ".")
}

function displayBob(){
    alert("Hello my name is" + Names[1] +  ".")
}

function displayJeremy(){
    alert("Hello my name is" + Names[2] + ".")
}

function displaySam(){
    alert("Hello my name is" + Names[3] + ".")
}

function displayHenry(){
    alert("Hello my name is" + Names[4] + ".")
}

function displaySarah(){
    alert("Hello my name is" + Names[5] + ".")
}

function displayAshley(){
    alert("Hello my name is" + Names[6] + ".")
}


displayAlice()
displayBob()
displayJeremy()
displaySam()
displayHenry()
displaySarah()
displayAshley()


console.log(Names[1],Names[3],Names[5],Names[7])

Names.reverse()

console.log(Names[6])

