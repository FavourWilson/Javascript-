var operator1 = 5;
var operator2 = 7;

var answer = operator1 + operator2
console.log(answer)

var answer = operator1 - operator2
console.log(answer)

var answer = operator1 * operator2
console.log(answer)

var answer = operator1 / operator2
console.log(answer)

function addNumber(operator1, operator2){
    return operator1 + operator2
}

addNumber(5,7)

function subtractNumber(operator1, operator2){
    return operator1 - operator2
}

subtractNumber(5,7)

function divideNumber(operator1, operator2){
    return operator1 / operator2
}

divideNumber(15,5)

function multiplyNumber(operator1, operator2){
    return operator1 * operator2
}

multiplyNumber(2,2)

